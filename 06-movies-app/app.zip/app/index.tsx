import { Redirect } from 'expo-router';
import React from 'react';

const MoviesApp = () => {
  console.log("AAAAAA");
  return <Redirect href='home' />
}

export default MoviesApp;